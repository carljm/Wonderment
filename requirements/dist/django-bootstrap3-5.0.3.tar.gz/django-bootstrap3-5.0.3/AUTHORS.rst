=======
Authors
=======

Development Lead
----------------

* Dylan Verheul <dylan@dyve.net>

Contributors
------------

* Allard Stijnman <a.g.stijnman@gmail.com>
* Austin Whittier <austin.whitt@gmail.com>
* Caio Ariede <caio.ariede@gmail.com>
* Fabio C. Barrionuevo da Luz <bnafta@gmail.com>
* Fabio Perfetti <perfabio87@gmail.com>
* Jay Pipes <jaypipes@gmail.com>
* Jonas Hagstedt <hagstedt@gmail.com>
* Jordan Starcher <jstarcher@gmail.com>
* Juan Carlos <juancarlospaco@gmail.com>
* Markus Holtermann <info@markusholtermann.eu>
* Nick S <nsmith448@gmail.com>
* Owais Lone <loneowais@gmail.com>
* pmav99 <pmav99@users.noreply.github.com>
* Richard Hajdu <tuskone16@gmail.com>
